import serverless from '../src/main';

export default serverless;
